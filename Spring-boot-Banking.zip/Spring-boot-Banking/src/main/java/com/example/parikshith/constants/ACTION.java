package com.example.parikshith.constants;

public enum ACTION {
    DEPOSIT,
    WITHDRAW
}
